# Exercises

For the workshop we prepared some notebooks to highlight features pyiron has to
offer.  First start a local jupyter lab session with
```bash
jupyter lab
```
in a folder where you'd like your notebooks to be stored.  This will open a tab
in your browser where you can create new notebooks.  Create one for each
exercise below and follow the instructions.  If you get stuck, you get start a
running copy of the solutions with the mybinder button (the little rocket) at
the top or start a jupyter lab session with all notebooks from
[here](https://mybinder.org/v2/gh/pmrv/pyiron-virtual-workshop-2020/master?urlpath=lab/tree/tutorials).
